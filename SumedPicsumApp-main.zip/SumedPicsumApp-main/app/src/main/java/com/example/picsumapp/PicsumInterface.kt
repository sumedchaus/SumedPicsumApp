package com.example.picsumapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query



interface PicsumInterface {

    @GET("/list")
    fun getImages(): Call<List<ImageData>>

}

