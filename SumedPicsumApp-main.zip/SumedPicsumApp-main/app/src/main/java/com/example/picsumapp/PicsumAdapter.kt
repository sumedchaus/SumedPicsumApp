package com.example.picsumapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.recyclelayout.view.*
import kotlin.math.log


class PicsumAdapter (val listImageData: List<ImageData>): RecyclerView.Adapter<PicsumViewHolder>(){
    /**
     * Holds reference of the tag value to show adapter log.
     */
    private  val TAG : String = PicsumAdapter::class.java.name


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PicsumViewHolder {
      Log.v(TAG, "onCreateViewHolder()")
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recyclelayout, parent, false)
        return PicsumViewHolder(view)
    }

    override fun getItemCount(): Int {
      Log.v(TAG, String.format("getItemCount() :: listImageData.size = %d", listImageData.size ))
        return listImageData.size
    }

    override fun onBindViewHolder(viewholder: PicsumViewHolder, position: Int) {
        Log.v(TAG, String.format("onBindViewHolder() :: listImageData id = %d, author = %s", listImageData[position].id, listImageData[position].author))
        return viewholder.bindView(listImageData[position])
    }
}
/**
 * ViewHolder for image layout.
 */

class PicsumViewHolder(itemView : View): RecyclerView.ViewHolder(itemView){

    /**
     * Binds view to the adapter.
     */

    fun bindView (imageData: ImageData) {
      if (imageData.id != null){
          Log.v(  "ImageAdapter ViewHolder",
              String.format("bindView() :: imageData.id = %d", imageData.id)
          )
          Glide.with(itemView.context)
              .load(ServiceBuilder.IMAGE_URL + imageData.id)
              .placeholder(R.drawable.ic_launcher_background)
              .error(R.drawable.ic_launcher_foreground)
              .override(300,300)
              .centerCrop()
              .into(itemView.imgvImage)
      }
        if (imageData.author != null && imageData.author.isNotEmpty()) {
            Log.v(
                "ImageAdapter ViewHolder",
                String.format("bindView() :: imageData.author = %s", imageData.author)
            )
            itemView.txtvAuthor.text = imageData.author
        }
    }

}
