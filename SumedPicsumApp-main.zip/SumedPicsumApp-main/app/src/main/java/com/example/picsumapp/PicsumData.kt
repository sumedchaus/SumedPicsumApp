package com.example.picsumapp



 data class ImageData (
     val id: Int,
     val author: String
 )


